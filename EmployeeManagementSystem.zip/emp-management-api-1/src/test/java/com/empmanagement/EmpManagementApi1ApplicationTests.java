package com.empmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpManagementApi1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
