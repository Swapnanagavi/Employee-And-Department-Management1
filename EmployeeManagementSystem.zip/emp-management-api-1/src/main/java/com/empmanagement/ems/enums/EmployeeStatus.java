package com.empmanagement.ems.enums;

public enum EmployeeStatus {
	ACTIVE,
    INACTIVE,
    ON_LEAVE
}
