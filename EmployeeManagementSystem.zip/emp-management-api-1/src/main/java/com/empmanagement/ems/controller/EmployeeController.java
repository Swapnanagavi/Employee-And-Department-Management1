package com.empmanagement.ems.controller;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.empmanagement.ems.DTO.EmployeeRequestDTO;
import com.empmanagement.ems.DTO.EmployeeResponseDTO;
import com.empmanagement.ems.enums.EmployeeStatus;
import com.empmanagement.ems.service.EmployeeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    // CREATE
    @PostMapping
    public ResponseEntity<EmployeeResponseDTO> createEmployee(
            @Valid @RequestBody EmployeeRequestDTO dto,
            @RequestParam Long departmentId) {

        return ResponseEntity.ok(employeeService.createEmployee(dto, departmentId));
    }

    // GET ALL (FILTERS)
    @GetMapping
    public ResponseEntity<List<EmployeeResponseDTO>> getAllEmployees(
            @RequestParam(required = false) EmployeeStatus status,
            @RequestParam(required = false) Long departmentId,
            @RequestParam(required = false) BigDecimal minSalary,
            @RequestParam(required = false) BigDecimal maxSalary) {

        return ResponseEntity.ok(
                employeeService.getAllEmployees(status, departmentId, minSalary, maxSalary));
    }

    // GET BY ID
    @GetMapping("/{id}")
    public ResponseEntity<EmployeeResponseDTO> getEmployeeById(@PathVariable Long id) {
        return ResponseEntity.ok(employeeService.getEmployeeById(id));
    }

    // UPDATE
    @PutMapping("/{id}")
    public ResponseEntity<EmployeeResponseDTO> updateEmployee(
            @PathVariable Long id,
            @Valid @RequestBody EmployeeRequestDTO dto) {

        return ResponseEntity.ok(employeeService.updateEmployee(id, dto));
    }

    // DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
        return ResponseEntity.noContent().build();
    }

    // CHANGE STATUS
    @PatchMapping("/{id}/status")
    public ResponseEntity<EmployeeResponseDTO> changeStatus(
            @PathVariable Long id,
            @RequestParam EmployeeStatus status) {

        return ResponseEntity.ok(employeeService.changeStatus(id, status));
    }

    // SEARCH
    @GetMapping("/search")
    public ResponseEntity<List<EmployeeResponseDTO>> searchEmployee(
            @RequestParam String name) {

        return ResponseEntity.ok(employeeService.searchEmployeeByName(name));
    }

    // TRANSFER
    @PutMapping("/{id}/transfer/{deptId}")
    public ResponseEntity<EmployeeResponseDTO> transferEmployee(
            @PathVariable Long id,
            @PathVariable Long deptId) {

        return ResponseEntity.ok(employeeService.transferEmployee(id, deptId));
    }
}