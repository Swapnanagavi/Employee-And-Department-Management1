package com.empmanagement.ems.service;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.empmanagement.ems.DTO.EmployeeRequestDTO;
import com.empmanagement.ems.DTO.EmployeeResponseDTO;
import com.empmanagement.ems.entity.Department;
import com.empmanagement.ems.entity.Employee;
import com.empmanagement.ems.enums.EmployeeStatus;
import com.empmanagement.ems.exception.BusinessException;
import com.empmanagement.ems.exception.DuplicateResourceException;
import com.empmanagement.ems.exception.ResourceNotFoundException;
import com.empmanagement.ems.repository.DepartmentRepository;
import com.empmanagement.ems.repository.EmployeeRepository;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    // CREATE EMPLOYEE
    public EmployeeResponseDTO createEmployee(
            EmployeeRequestDTO employeeDTO,
            Long departmentId) {

        // Duplicate email check
        if (employeeRepository.findByEmail(employeeDTO.getEmail()).isPresent()) {
            throw new DuplicateResourceException("Email already exists");
        }

        // Salary validation
        if (employeeDTO.getSalary().compareTo(BigDecimal.ZERO) <= 0
                || employeeDTO.getSalary().compareTo(new BigDecimal("1000000")) > 0) {

            throw new BusinessException(
                    "Salary must be between 1 and 10,00,000");
        }

        // Joined date validation
        if (employeeDTO.getJoinedDate().isAfter(LocalDate.now())) {

            throw new BusinessException(
                    "Joined date cannot be a future date");
        }

        // Fetch department
        Department department = departmentRepository.findById(departmentId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Department not found"));

        // Capacity check
        long employeeCount =
                employeeRepository.countByDepartmentId(departmentId);

        if (employeeCount >= department.getMaxCapacity()) {

            throw new BusinessException(
                    "Department has reached maximum capacity");
        }

        // DTO → ENTITY
        Employee employee = new Employee();

        employee.setFirstName(employeeDTO.getFirstName());
        employee.setLastName(employeeDTO.getLastName());
        employee.setEmail(employeeDTO.getEmail());
        employee.setPhone(employeeDTO.getPhone());
        employee.setSalary(employeeDTO.getSalary());
        employee.setStatus(employeeDTO.getStatus());
        employee.setJoinedDate(employeeDTO.getJoinedDate());

        employee.setDepartment(department);

        // SAVE
        Employee savedEmployee =
                employeeRepository.save(employee);

        // ENTITY → DTO
        return mapToDTO(savedEmployee);
    }

    // GET ALL EMPLOYEES
    public List<EmployeeResponseDTO> getAllEmployees(
            EmployeeStatus status,
            Long departmentId,
            BigDecimal minSalary,
            BigDecimal maxSalary) {

        List<Employee> employees;

        if (status != null && departmentId != null
                && minSalary != null && maxSalary != null) {

            employees =
                    employeeRepository
                            .findByStatusAndDepartment_IdAndSalaryBetween(
                                    status,
                                    departmentId,
                                    minSalary,
                                    maxSalary);

        } else if (status != null) {

            employees = employeeRepository.findByStatus(status);

        } else if (departmentId != null) {

            employees =
                    employeeRepository.findByDepartment_Id(departmentId);

        } else if (minSalary != null && maxSalary != null) {

            employees =
                    employeeRepository.findBySalaryBetween(
                            minSalary,
                            maxSalary);

        } else {

            employees = employeeRepository.findAll();
        }

        return employees.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    // GET BY ID
    public EmployeeResponseDTO getEmployeeById(Long id) {

        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Employee not found with id: " + id));

        return mapToDTO(employee);
    }

    // UPDATE EMPLOYEE
    public EmployeeResponseDTO updateEmployee(
            Long id,
            EmployeeRequestDTO employeeDTO) {

        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Employee not found"));

        BigDecimal currentSalary = employee.getSalary();
        BigDecimal newSalary = employeeDTO.getSalary();

        BigDecimal limit =
                currentSalary.multiply(new BigDecimal("1.5"));

        if (newSalary.compareTo(limit) > 0) {

            throw new BusinessException(
                    "Salary hike exceeds 50% limit.Please get HR approval");
        }

        employee.setFirstName(employeeDTO.getFirstName());
        employee.setLastName(employeeDTO.getLastName());
        employee.setPhone(employeeDTO.getPhone());
        employee.setSalary(employeeDTO.getSalary());
        employee.setStatus(employeeDTO.getStatus());
        employee.setJoinedDate(employeeDTO.getJoinedDate());

        Employee updatedEmployee =
                employeeRepository.save(employee);

        return mapToDTO(updatedEmployee);
    }

    // DELETE
    public void deleteEmployee(Long id) {

        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Employee not found"));

        employeeRepository.delete(employee);
    }

    // CHANGE STATUS
    public EmployeeResponseDTO changeStatus(
            Long id,
            EmployeeStatus status) {

        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Employee not found"));

        employee.setStatus(status);

        Employee updatedEmployee =
                employeeRepository.save(employee);

        return mapToDTO(updatedEmployee);
    }

    // TRANSFER EMPLOYEE
    public EmployeeResponseDTO transferEmployee(
            Long employeeId,
            Long departmentId) {
    	

        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Employee not found"));

        Department department = departmentRepository.findById(departmentId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Department not found"));
        // INACTIVE employee cannot transfer
        if (employee.getStatus() == EmployeeStatus.INACTIVE) {

            throw new BusinessException(
                    "Inactive employee cannot be transferred.");
        }

        // Check department capacity
        long employeeCount =
                employeeRepository.countByDepartmentId(departmentId);

        if (employeeCount >= department.getMaxCapacity()) {

            throw new BusinessException(
                    "Department has reached its maximum capacity.");
        }

        employee.setDepartment(department);

        Employee updatedEmployee =
                employeeRepository.save(employee);

        return mapToDTO(updatedEmployee);
    }

    // SEARCH EMPLOYEE
    public List<EmployeeResponseDTO> searchEmployeeByName(
            String name) {

        List<Employee> employees =
                employeeRepository
                        .findByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCase(
                                name,
                                name);

        return employees.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    // ENTITY → DTO MAPPING
    private EmployeeResponseDTO mapToDTO(Employee employee) {

        EmployeeResponseDTO dto =
                new EmployeeResponseDTO();

        dto.setId(employee.getId());
        dto.setFirstName(employee.getFirstName());
        dto.setLastName(employee.getLastName());
        dto.setEmail(employee.getEmail());
        dto.setPhone(employee.getPhone());
        dto.setSalary(employee.getSalary());
        dto.setStatus(employee.getStatus());
        dto.setJoinedDate(employee.getJoinedDate());
        dto.setUpdatedAt(employee.getUpdatedAt());

        if (employee.getDepartment() != null) {

            dto.setDepartmentId(
                    employee.getDepartment().getId());

            dto.setDepartmentName(
                    employee.getDepartment().getName());
        }

        return dto;
    }
}