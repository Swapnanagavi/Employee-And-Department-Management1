package com.empmanagement.ems.repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.empmanagement.ems.entity.Employee;
import com.empmanagement.ems.enums.EmployeeStatus;

public interface EmployeeRepository
        extends JpaRepository<Employee, Long> {

    // Check duplicate email
    Optional<Employee> findByEmail(String email);

    // Search employees by first name
    List<Employee> findByFirstNameContainingIgnoreCase(
            String name);

    // Search employees by first name OR last name
    List<Employee>
    findByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCase(
            String firstName,
            String lastName);

    // Filter by status
    List<Employee> findByStatus(
            EmployeeStatus status);

    // Filter by department
    List<Employee> findByDepartmentId(
            Long departmentId);

    // Filter by department using entity relation
    List<Employee> findByDepartment_Id(
            Long departmentId);

    // Filter by salary range
    List<Employee> findBySalaryBetween(
            BigDecimal minSalary,
            BigDecimal maxSalary);

    // Count employees in department
    long countByDepartmentId(
            Long departmentId);

    // Combined filters
    List<Employee>
    findByStatusAndDepartment_IdAndSalaryBetween(
            EmployeeStatus status,
            Long departmentId,
            BigDecimal minSalary,
            BigDecimal maxSalary);

    // Status + Department
    List<Employee> findByDepartmentIdAndStatus(
            Long departmentId,
            EmployeeStatus status);

    // Department + Salary
    List<Employee> findByDepartmentIdAndSalaryBetween(
            Long departmentId,
            BigDecimal minSalary,
            BigDecimal maxSalary);

    // Status + Salary
    List<Employee> findByStatusAndSalaryBetween(
            EmployeeStatus status,
            BigDecimal minSalary,
            BigDecimal maxSalary);
}