package com.empmanagement.ems.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.empmanagement.ems.DTO.EmployeeResponseDTO;
import com.empmanagement.ems.entity.Department;
import com.empmanagement.ems.entity.Employee;
import com.empmanagement.ems.exception.BusinessException;
import com.empmanagement.ems.exception.DuplicateResourceException;
import com.empmanagement.ems.exception.ResourceNotFoundException;
import com.empmanagement.ems.repository.DepartmentRepository;
import com.empmanagement.ems.repository.EmployeeRepository;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    // CREATE
    public Department createDepartment(Department department) {

        if (departmentRepository.existsByName(department.getName())) {
            throw new DuplicateResourceException("Department name already exists");
        }

        if (department.getMaxCapacity() < 1 || department.getMaxCapacity() > 50) {
            throw new BusinessException("Max capacity must be between 1 and 50");
        }

        return departmentRepository.save(department);
    }

    // GET ALL
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    // GET BY ID
    public Department getDepartmentById(Long id) {
        return departmentRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Department not found with id: " + id));
    }

    // UPDATE
    public Department updateDepartment(Long id, Department updated) {

        Department dept = getDepartmentById(id);

        if (!dept.getName().equalsIgnoreCase(updated.getName())
                && departmentRepository.existsByName(updated.getName())) {
            throw new DuplicateResourceException("Department name already exists");
        }

        if (updated.getMaxCapacity() < 1 || updated.getMaxCapacity() > 50) {
            throw new BusinessException("Max capacity must be between 1 and 50");
        }

        dept.setName(updated.getName());
        dept.setLocation(updated.getLocation());
        dept.setMaxCapacity(updated.getMaxCapacity());

        return departmentRepository.save(dept);
    }

    // DELETE
    public void deleteDepartment(Long id) {

        Department dept = getDepartmentById(id);

        List<Employee> employees = employeeRepository.findByDepartmentId(id);

        if (!employees.isEmpty()) {
            throw new BusinessException("Cannot delete department with active employees.");
        }

        departmentRepository.delete(dept);
    }

    // ⭐ FIXED: GET EMPLOYEES BY DEPARTMENT (DTO SAFE)
    public List<EmployeeResponseDTO> getEmployeesByDepartment(Long departmentId) {

        Department dept = getDepartmentById(departmentId);

        List<Employee> employees = employeeRepository.findByDepartmentId(departmentId);

        return employees.stream()
                .map(emp -> {
                    EmployeeResponseDTO dto = new EmployeeResponseDTO();

                    dto.setId(emp.getId());
                    dto.setFirstName(emp.getFirstName());
                    dto.setLastName(emp.getLastName());
                    dto.setEmail(emp.getEmail());
                    dto.setPhone(emp.getPhone());
                    dto.setSalary(emp.getSalary());
                    dto.setStatus(emp.getStatus());
                    dto.setJoinedDate(emp.getJoinedDate());
                    dto.setDepartmentId(dept.getId());
                    
                    if (emp.getDepartment() != null) {
                        dto.setDepartmentId(emp.getDepartment().getId());
                        dto.setDepartmentName(emp.getDepartment().getName());
                    }

                    return dto;
                })
                .collect(Collectors.toList());
    }
}