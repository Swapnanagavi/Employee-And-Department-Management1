package com.empmanagement.ems.DTO;


import java.math.BigDecimal;
import java.time.LocalDate;

import com.empmanagement.ems.enums.EmployeeStatus;

import jakarta.validation.constraints.*;

public class EmployeeRequestDTO {

    @NotBlank(message = "First name is required")
    @Size(max = 80)
    private String firstName;

    @NotBlank(message = "Last name is required")
    @Size(max = 80)
    private String lastName;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email")
    private String email;

    @Size(max = 15)
    private String phone;

    @NotNull(message = "Salary is required")
    @DecimalMin(value = "0.01")
    @DecimalMax(value = "1000000.00")
    private BigDecimal salary;

    @NotNull(message = "Status is required")
    private EmployeeStatus status;

    @NotNull(message = "Joined date is required")
    @PastOrPresent(message = "Joined date cannot be future")
    private LocalDate joinedDate;

    

    // Getters and Setters

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public EmployeeStatus getStatus() {
        return status;
    }

    public void setStatus(EmployeeStatus status) {
        this.status = status;
    }

    public LocalDate getJoinedDate() {
        return joinedDate;
    }

    public void setJoinedDate(LocalDate joinedDate) {
        this.joinedDate = joinedDate;
    }

    
}
