package com.empmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpManagementApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmpManagementApi1Application.class, args);
	}

}
